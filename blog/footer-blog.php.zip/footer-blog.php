
<section id="footer">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-3 col-sm-6">
				<h3><span>Our</span> Links</h3>
					<a href="#"><p>Rentals</p></a>
					<a href="../service-repair.php"><p>Services & Repairs</p></a>
					<a href="../about.php"><p>Our Story</p></a>
					<a href="../trusted.php"><p>Trusted By</p></a>
					<a href="../news.php"><p>News & Resources</p></a>
					<a href="../contact.php"><p>Contact us</p></a>
					<a href="../privacy-policy.php"><p>Privacy Policy</p></a>
					 <a  href="blogs.php" target="blank"><p>Blogs</p></a>
			</div>


			 <div class="col-md-3 col-sm-6 top">
				<img src="../images/logo2.png" class="img-responsive" alt="yesautomation"/>
					<p>YES AUTOMATION LLC</p>
					<p>BLOCK NO. 7,<br> WAREHOUSE NO 3</p>
					<p>UM LAOB REGION,<br> PLOT NO. 1628</p>
					<p>UMM AL QUWAIN, UAE</p>
					
			</div> 


			<div class="col-md-3 col-sm-6">
					<h3><span>Get In</span> Touch</h3>		
					<p>TEL : +971 6 5264382</p>
					<p>MOB : +971 52 797 2211</p>
					<p>FAX : +971 6 5264384</p>
					<p>Mail : <a href="mailto:sales@yesautomation.ae">sales@yesautomation.ae</a></p>
			</div>
			<div class="col-md-3 col-sm-6 lo-fo">
					<img src="../images/logo.png">
			</div>






		</div>

	</div>

</section>


<section id="rated-main">	
				<div class="container-fluid">
					<div class="row">
					</div>
				</div>


			<section id="back">
				<div class="container-fluid">
					<div class="col-md-7 col-sm-9">
						<p>© 2021  <span>YesAutomation.ae</span> All rights reserved.  Powered By  <a href="http://bigleap.ae/" target="blank"><span>Big Leap</span></a></p>
							</div>

						<div class="col-md-5 col-sm-3">				
					 <a href="https://www.instagram.com/p/B_UL3NPHrXN/?igshid=1iohucpf6oh2e" target="blank" class="le"><i class="demo-icon icon-instagram">&#xe812;</i></a>
                     <a class="le" target="blank" href="https://www.linkedin.com/company/yes-automation/"><i class="demo-icon icon-linkedin">&#xf0e1;</i></a>
                    <a href="https://www.facebook.com/YES-Automation-109242957330326/" class="le"  target="blank"><i class="demo-icon icon-003-facebook">&#xe808;</i></a>
                    

				</div>
			</div>
	</section>
</section>
